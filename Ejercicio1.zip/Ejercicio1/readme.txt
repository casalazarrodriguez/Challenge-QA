Instrucciones para ejecutar el escenario:
1.	Abrir IntelliJ IDEA.
2.	Para abrir el proyecto click en File/Open.
3.	Ubicar el proyecto en la ruta guardada y presionar botón OK para abrir.
4.	Una vez hayan cargado todas las dependencias, ingresar a la carpeta src/test/java/com/swag/pe/utilities y abrir el Runner.java .
5.	Diríjase en la fija 13 Public class Runner, haga click derecho y seleccionar Run ‘Runner’ .
6.	El proyecto procederá a ejecutarse.
7.	Para obtener el reporte dashboard del proyecto ejecutado, seleccionar pestaña Mave y hacer clic en Execute Maven Goal.
8.	Dijitar mvn serenity:aggregate, esperar a que termine de cargar y seleccionar la ruta mostrada en consola.
